config_require(disman/schedule/schedCore);
config_require(disman/schedule/schedConf);
config_require(disman/schedule/schedTable);
